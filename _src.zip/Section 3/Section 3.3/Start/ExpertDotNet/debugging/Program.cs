﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Debugging
{
    class Program
    {
        static void Main(string[] args)
        {
            Debugging_Fun();
        }

        private static void Debugging_Fun()
        {
            // Debug for life!
           
        }
    }
}
