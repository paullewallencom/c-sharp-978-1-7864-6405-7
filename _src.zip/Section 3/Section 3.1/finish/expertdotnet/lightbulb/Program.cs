﻿
namespace LightBulb
{
    class Program
    {
        private static List<string> theStudents;
        static void Main(string[] args)
        {
            //  Some Fancy Code
        }
    }
}
