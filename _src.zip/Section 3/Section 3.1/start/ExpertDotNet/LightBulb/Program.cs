﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LightBulb
{
    class Program
    {
        private static List<string> theStudents;
        static void Main(string[] args)
        {
            //  Some Fancy Code
        }
    }
}
