﻿namespace AutoProperty
{
    class Singer
    {        
        public string Name { get; set; } = "A great singer";
        public int Age { get; set; }
    }
}