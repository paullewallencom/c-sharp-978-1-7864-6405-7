﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Await
{
    class Program
    {
        static void Main(string[] args)
        {
            Test_AsyncInCatchFinally();
        }

        /// <summary>
        /// Await in catch and finally blocks
        /// </summary>
        /// <returns></returns>
        private static async void Test_AsyncInCatchFinally()
        {
            // TODO
        }
    }
}
