﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NullConditional
{
    class Singer
    {
        public int Age { get; internal set; }
        public string Name { get; internal set; }
    }
}
